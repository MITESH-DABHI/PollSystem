7yim/jc6tg#include<stdio.h>
int push(int s[],int *top,int n)
{
    if(*top==99)
    {
        printf("limit full");
    }
    else
    {
        *top=*top+1;
        s[*top]=n;
    }
}
int pop(int s[],int *top)
{
    if(*top==-1)
    {
        printf("Enter some value!!");
    }
    else
    {
        int k=s[*top];
        printf("%d",k);
        *top=*top-1;
    }
}
int DtoB(int n)
{
    int top=-1;
    int s[100];
    while(n!=0)
    {
        push(s,&top,n%2);
        n=n/2;
    }
    while(top!=-1)
    {
        pop(s,&top);
    }
}
int main()
{
    int n;
    printf("Enter the Decimal no. you want to convert into binary:");
    scanf("%d",&n);
    DtoB(n);
    return 0;
}